<?php include 'sendmail-Career.php'?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<title>Rcokland Security Career</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" href="images/icon.png">
</head>

	<body>

		<!--alert messages start-->
    	<?php echo $alert; ?>
    	<!--alert messages end-->

		<nav>
			<div class="frst_nav_container">

				<div class="burger_container">
				<div class="head_div"> 
					<a href="index.php"><img class="logo_" src="images/logo2.png"></a>
				</div>

				<div id="wrapper" class="toggle">
					<div class="circle icon">
						<span class="line top"></span>
						<span class="line middle"></span>
						<span class="line bottom"></span>
					</div>
				</div>

		  		</div>

				<div class="contact_header_container">
					<div class="head_div head_div1">
						<p>EMAIL US<br>
						<span> <a href="mailto:info@rocklandprotection.ca">info@rocklandprotection.ca</a></span>		</p>
					</div>

					<div class="head_div head_div2">
						<p>CALL US<br>
						<span><a href="tel:778-700-4146">(778)-700-4146</a></span></p>
					</div>

					<div class="head_div head_div3">
						<p>CONTACT US<br>
						<span><a href="contactus.php#writeus">Write us a message</a></span></p>
					</div>
				</div>

				

			</div>
			
			<div class="second_nav_background">
				
				<div class="second_nav_container">
					
					<ul class="menu">
			            <li class="item"><a href="index.php">HOME</a></li>
			            <li class="item"><a href="services.php">SERVICES</a></li>
			            <li class="item"><a href="aboutus.php">ABOUT US</a></li>
			            <li class="item"><a href="career.php">CAREERS</a></li>
			            <li class="item"><a href="contactus.php">CONTACT US</a></li>
			 
			            <li class="item button"><a href="quote.php#request">Get Quote</a></li>
			            <!-- <li class="item button secondary"><a href="#">Sign Up</a></li> -->
			            <!-- <li class="toggle"><span class="bars"></span></li> -->
        			</ul>

				</div>
			
			</div>
		</nav>
		<main>
			<div class="career_bg">
				<div class="banner_container">
						<div class="banner_content">
							<p>be part be prepared</p>
							<p>get a career in security</p>
							<p class="change_p">Locally Owned & Managed Security Guard Company in British Columbia, CA </p>	

							<!-- <div class="banner_div_button">
							<a href="#"> <button> Submit Resume</button></a>
							</div> -->
						</div>
					</div>
			</div>

			<div class="career_content_container">

				<div class="career_yellow_wrapper">
					<div class="career_yellow_content">
					<p>If you are looking to start your security career, Rockland can provide you with the skills to enhance your personal and professional development in a positive environment, where your growth is supported and your talent is recognized.</p>
					</div>
				</div>

				<div class="career_frmcontainer">

					<div class="career_divtxt" > 

						<div>
							<h1>be part of <br>our team</h1>
					<!-- <p>We’re looking for people to join the team who are as excited as we are to help build and provide safety security for our clients business. 	</p> -->

					<p>
					Build your career with us! <br>competitive wage <br>medical and dental health benefits <br>after provasionary </p>
						</div>

						<div>
							<p>Questions ?</p>
							<p>Call us : <a href="tel:778-700-4146">(778)-700-4146</a> </p>
							<p>Email us : <a href="mailto:career@rocklandsecurity.ca">career@rocklandsecurity.ca</a></p>
						</div>
					</div>

					<div class="frm_resumecontainer">
						<!-- <p>Write Us a Message</p> -->
						<form class="frm_resume" accept="" method="post" enctype="multipart/form-data">
							<input type="text" id="" class="resumetxt" 
							name="name" placeholder="Full Name" required><br>
							<input type="text" id="" class="resumetxt" 
							name="licensenum" placeholder="BC Security License Number" required><br>
							<input type="email" id="" class="resumetxt" 
							name="email" placeholder="Email" required><br>
							<input type="Number" id="" class="resumetxt" 
							name="phone" placeholder="Phone Number" required><br>
							<p><label  >Resume : </label> <br> <br>
							<input type="file" class="myfile" id="myfile1" 
							name="resume" accept="docm,.doc,.docx,.txt,.pdf" required></p><br>
							<p><label>Cover Letter : </label> <br><br>
							<input type="file" class="myfile"  id="myfile2" 
							name="coverletter" accept="docm,.doc,.docx,.txt,.pdf" required></p>
							<div class="resume_button_text">
							<input type="submit" class="careersbmt" value="Submit"
							name="submit"> <p></p>
							</div>
						</form>
					</div>
				</div>

					<!-- <div class="career_yellow_wrapper"> 

						<div class="career_yellow_content">
						
							
							<p>Start building a rewarding career with the fastest growing and well reputable security company in South East Asia. If you think you have what it takes, send us your application apply online for career opportunities.</p>
						</div>
					</div>	 -->
			

					<!-- 	<div class="main_purple">
				<div>
					
				</div>
			</div> -->

				</div>	


	
		</main>
		<footer>
			
			<div class="footer_container">

				<div class="footer_first_layer">

					<div class="ftr_contact_container0">	
						<div class="ftr_contact_container">
							
							<div class="ftr_icon_container">
							<img class="ftr_icon" src="images/icons/map.png">
							</div>
							
							<div>
							12915 88 Ave Surrey, <br>
							BC V3W 3K2
							Canada
							</div>

						</div>

						<div class="ftr_contact_container">

							<div class="ftr_icon_container">
							<img class="ftr_icon" src="images/icons/mail.png">
							</div>

							<div>
							Email Us :<br>
							<a href="mailto:info@rocklandprotection.ca">info@rocklandsecurity.ca</a>	
							</div>

						</div>
						
						<div class="ftr_contact_container">

							<div class="ftr_icon_container">
							<img class="ftr_icon" src="images/icons/phone.png">
							</div>

							<div>
							Call us :<br>
							<a href="tel:778-700-4146">(778)-700-4146</a>
							</div>

						</div>
					</div>
					
				</div>

				<div class="footer_second_layer">
					<div class="footer_nav">
					<span>Site Navigation</span>
					<ul>
						<li><a href="index.php">- Home </a></li>
						<li><a href="services.php">- Services </a></li>
						<li><a href="aboutus.php">- About Us </a></li>
						<li><a href="career.php">- Careers </a></li>
						<li><a href="contactus.php">- Contact Us </a></li>
					</ul>
					</div>

					<div class="company_info">						
						<span>Rockland Protection Security</span> <br>		
							
							Established in 1993 the company in the Philippines can boast of being one of the most efficient, competitive, highly motivated and innovative in the industry. Our security guards are carefully selected and have undergone extensive training on all aspects of security and safety. A continuous training program is being implemented by the company for its security guards to make them cope-up with the day to day problems being encountered in security and safety business.
					</div>

				</div>

				<div class="cright">
					© Copyrights 2020 rocklandsecurity.ca
				</div>
				
			</div>

		</footer>

	</body>

</html>

<!-- SCRIPT NG HAMBURGER backup just in case-->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
    crossorigin="anonymous">
</script>

<!-- JS FILE LOCATION -->
<script type="text/javascript" src="script.js"></script>

<!-- PHPMAILER -->
<script type="text/javascript">
    if(window.history.replaceState){
      window.history.replaceState(null, null, window.location.href);
    }
    </script>
