<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
	<title>Rcokland Security Services</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="icon" href="images/icon.png">
</head>

	<body>
		<nav>
			<div class="frst_nav_container">

				<div class="burger_container">
				<div class="head_div"> 
					<a href="index.php"><img class="logo_" src="images/logo2.png"></a>
				</div>

				<div id="wrapper" class="toggle">
					<div class="circle icon">
						<span class="line top"></span>
						<span class="line middle"></span>
						<span class="line bottom"></span>
					</div>
				</div>

		  		</div>

				<div class="contact_header_container">
					<div class="head_div head_div1">
						<p>EMAIL US<br>
						<span> <a href="mailto:info@rocklandprotection.ca">info@rocklandprotection.ca</a></span>		</p>
					</div>

					<div class="head_div head_div2">
						<p>CALL US<br>
						<span><a href="tel:778-700-4146">(778)-700-4146</a></span></p>
					</div>

					<div class="head_div head_div3">
						<p>CONTACT US<br>
						<span><a href="Contactus.php#writeus">Write us a message</a></span></p>
					</div>
				</div>

				

			</div>
			
			<div class="second_nav_background">
				
				<div class="second_nav_container">
					
					<ul class="menu">
			            <li class="item"><a href="index.php">HOME</a></li>
			            <li class="item"><a href="services.php">SERVICES</a></li>
			            <li class="item"><a href="aboutus.php">ABOUT US</a></li>
			            <li class="item"><a href="career.php">CAREER</a></li>
			            <li class="item"><a href="contactus.php">CONTACT US</a></li>
			 
			            <li class="item button"><a href="quote.php#request">Get Quote</a></li>
			            <!-- <li class="item button secondary"><a href="#">Sign Up</a></li> -->
			            <!-- <li class="toggle"><span class="bars"></span></li> -->
        			</ul>

				</div>
			
			</div>
		</nav>
		<main>
			<div class="services_bg">

				<div class="banner_container">
						<div class="banner_content">
							<p>Remarkable Security </p>
							<p>service provider</p>
							<p class="change_p">Locally Owned & Managed Security Guard Company in British Columbia, CA </p>	

							<div class="banner_div_button">
							<a href="quote.php#request"> <button> Get Quote</button></a>
							</div>
						</div>
					</div>
			</div>

			<div class="services_background_container">

				<div class="container_header">

						<div class="container_header_bg">

							<div class="container_header_logo">

								<img src="images/logo.png">

							</div>

							<div class="container_header_texts">			

								<div>
								<p>Why choose us?</p>
								<p>We offer highly trained security guard and security patrol services. We take pride in our services to ensure that we meet highest level of satisfaction for our clients.</p>
								</div>
							</div>

							<div class="container_header_contact">

								<p>Need Help?</p>
								<p>Email us : <a href="mailto:info@rocklandsecurity.ca">info@rocklandsecurity.ca</a></p>
								<p>Call us : <a href="tel:(778)-700-4146">(778)-700-4146</a></p>

							</div>
							
						</div>

					</div>

				<div class="services_container">


					<div class="services-content-container">

						<div class="services-bg-container">
							
							<div class="bg-image-services">

							</div>

							<div class="bg-services-btn">
								<p><a href="quote.php#request"> <button>Get Quotation</button></a></p>
							</div>

						</div>

						<div class="services-content-text">

							<div class="services_title_div">
								<p>Top-notch Services</p>

								<p>Rockland Security  offers a wide array of services to its clients.  Our services are designed to provide complete customer satisfaction and peace of mind because our security guards are carefully selected and have undergone extensive training on all aspects of security and safety.</p>
							</div>

							<div class="services-content-divider1">
							<p>
								We offer the following services:				
								<ul class="services-list">
									<li>GUARD SERVICES</li>
									<li>MOBILE PATROLS</li>
									<li>TEMPORARY SECURITY</li>
									<li>SUPERVISORY & SUPPORT STRUCTURE</li>
									<li>LOSS PREVENTION</li>
									<li>MOBILE SECURITY PATROL</li>
									<li>ALARM AND RESPONSE</li>
									<li>CONCIERGE. </li>
								</ul>
							</p>
							</div>

							<div class="services-content-divider2">
							<p>We provide the following services:</p>

								<ul class="services-list">
								<li>ALARM AND RESPONSE</li>
								<li>UNIFORM SECURITY</li> 
								<li>K9 SERVICE</li>
								<li>MOBILE SECURITY</li>
								</ul>
							</div>
							
								<div class="services-content-divider3">
									<p>We serve all industries like:</p>
									<ul class="services-list">
									<li>Office Buildings</li>
									<li>Medical Centers</li>
									<li>Hospitals</li>
									<li>Hotels</li>
									<li>Distribution Centers</li>
									<li>Trucking Companies</li>
									<li>Manufacturing Companies</li>
									<li>Homeowner Associations</li>
									<li>Shopping Centers</li>
									<li>High Rise Commercial</li>
									<li>Apartment complexes</li>
									<li>Grocery Stores</li>
									<li>Retail Stores</li>
									</ul>
								</div>							
						</div>
							
					</div>

					
				</div>	


					<div class="hire-us">
									<div class="hire-title"><p>Hire us today!</p></div>
									<div class="shape-divider">
										<div class="bar"></div>
										<div class="square"></div>
										<div class="bar"></div>
									</div>
									<div class="hire-context"><p>Request a quote with us today your request is important to us.</p></div>

									<div class="secrete_btn">
								<p><a href="quote.php#request"> <button>Get Quotation</button></a></p>
							</div>

								</div>

			<div class="why-choose-us-bg">
						<div class="why-choose-container">
							<div class="why-choose-title">
	
								<p>Why Choose Us</p>
					
							</div>

							<div class="why-choose-content">
								
								<div class="why-choose-content1">
									<p>01</p>
									<p>Quality Service</p>
									<p>We offer the best security guard and security patrol services</p>
								</div>

								<div class="why-choose-conten2">
									<p>02</p>
									<p>Highly Trained</p>
									<p>Our security guards are carefully selected and have undergone extensive training on  all aspects of security and safety.</p>
								</div>

								<div class="why-choose-conten3">
									<p>03</p>
									<p>Best Price</p>
									<p>We offer you the best pricing table in town.</p>
								</div>

								
							</div>
							
						</div>
					</div>
		</main>
		<footer>
			
			<div class="footer_container">

				<div class="footer_first_layer">

					<div class="ftr_contact_container0">	
						<div class="ftr_contact_container">
							
							<div class="ftr_icon_container">
							<img class="ftr_icon" src="images/icons/map.png">
							</div>
							
							<div>
							12915 88 Ave Surrey, <br>
							BC V3W 3K2
							Canada
							</div>

						</div>

						<div class="ftr_contact_container">

							<div class="ftr_icon_container">
							<img class="ftr_icon" src="images/icons/mail.png">
							</div>

							<div>
							Email Us :<br>
							<a href="mailto:info@rocklandprotection.ca">info@rocklandsecurity.ca</a>	
							</div>

						</div>
						
						<div class="ftr_contact_container">

							<div class="ftr_icon_container">
							<img class="ftr_icon" src="images/icons/phone.png">
							</div>

							<div>
							Call us :<br>
							<a href="tel:778-700-4146">(778)-700-4146</a>
							</div>

						</div>
					</div>
					
				</div>

				<div class="footer_second_layer">
					<div class="footer_nav">
					<span>Site Navigation</span>
					<ul>
						<li><a href="index.php">- Home </a></li>
						<li><a href="services.php">- Services </a></li>
						<li><a href="aboutus.php">- About Us </a></li>
						<li><a href="career.php">- Career </a></li>
						<li><a href="contactus.php">- Contact Us </a></li>
					</ul>
					</div>

					<div class="company_info">						
						<span>Rockland Protection Security</span> <br>		
							
							Established in 1993 the company in the Philippines can boast of being one of the most efficient, competitive, highly motivated and innovative in the industry. Our security guards are carefully selected and have undergone extensive training on all aspects of security and safety. A continuous training program is being implemented by the company for its security guards to make them cope-up with the day to day problems being encountered in security and safety business.
					</div>

				</div>

				<div class="cright">
					© Copyrights 2020 rocklandsecurity.ca
				</div>
				
			</div>

		</footer>

	</body>

</html>

<!-- SCRIPT NG HAMBURGER backup just in case-->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8="
    crossorigin="anonymous">
</script>

<!-- JS FILE LOCATION -->
<script type="text/javascript" src="script.js"></script>
